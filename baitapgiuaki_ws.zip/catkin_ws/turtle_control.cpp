<launch>
    <!-- Khởi chạy turtlesim node -->
    <node name="turtlesim" pkg="turtlesim" type="turtlesim_node" output="screen"/>

    <!-- Chạy node điều khiển rùa -->
    <node name="turtle_control" pkg="turtle_control" type="turtle_control" output="screen"/>
</launch>
