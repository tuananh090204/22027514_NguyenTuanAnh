#!/usr/bin/env python3
import rospy
import sys
import termios
import tty
from std_msgs.msg import Float64

def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        key = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return key

def teleop_control():
    rospy.init_node('teleop_joint_control', anonymous=True)
    pub_xoay = rospy.Publisher('/meca/xoay_Joint/command', Float64, queue_size=10)
    pub_tinhtien = rospy.Publisher('/meca/tinhtien_Joint/command', Float64, queue_size=10)

    position_xoay = Float64()
    position_tinhtien = Float64()
    
    rospy.loginfo("Use 'w/s' for tinhtien_Joint and 'a/d' for xoay_Joint. Press 'q' to quit.")
    
    rate = rospy.Rate(10)  # 10 Hz
    while not rospy.is_shutdown():
        key = get_key()
        
        if key == 'w':
            position_tinhtien.data += 0.005  # Dịch chuyển lên
        elif key == 's':
            position_tinhtien.data -= 0.005  # Dịch chuyển xuống
        elif key == 'a':
            position_xoay.data += 0.1  # Quay trái
        elif key == 'd':
            position_xoay.data -= 0.1  # Quay phải
        elif key == 'q':
            rospy.loginfo("Exiting teleop control.")
            break
        
        rospy.loginfo(f"xoay_Joint: {position_xoay.data}, tinhtien_Joint: {position_tinhtien.data}")
        pub_xoay.publish(position_xoay)
        pub_tinhtien.publish(position_tinhtien)
        
        rate.sleep()

if __name__ == '__main__':
    try:
        teleop_control()
    except rospy.ROSInterruptException:
        pass
