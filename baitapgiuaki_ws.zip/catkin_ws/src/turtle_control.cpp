#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <turtlesim/Spawn.h>
#include <turtlesim/Pose.h>
#include <cmath>

ros::Publisher pub1, pub2;
turtlesim::Pose pose1, pose2;
bool collision_detected = false;

// Hàm callback cập nhật vị trí rùa 1
void poseCallback1(const turtlesim::Pose::ConstPtr& msg) {
    pose1 = *msg;
}

// Hàm callback cập nhật vị trí rùa 2
void poseCallback2(const turtlesim::Pose::ConstPtr& msg) {
    pose2 = *msg;
}

// Hàm tính khoảng cách giữa hai con rùa
double getDistance(const turtlesim::Pose& p1, const turtlesim::Pose& p2) {
    return std::sqrt(std::pow(p1.x - p2.x, 2) + std::pow(p1.y - p2.y, 2));
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "turtle_control");
    ros::NodeHandle nh;

    // Gọi dịch vụ spawn để sinh hai con rùa mới
    ros::ServiceClient spawnClient = nh.serviceClient<turtlesim::Spawn>("/spawn");
    turtlesim::Spawn spawn1, spawn2;

    spawn1.request.x = 2.0;
    spawn1.request.y = 2.0;
    spawn1.request.theta = 0.0;
    spawn1.request.name = "turtle1";

    spawn2.request.x = 7.0;
    spawn2.request.y = 7.0;
    spawn2.request.theta = 0.0;
    spawn2.request.name = "turtle2";

    spawnClient.call(spawn1);
    spawnClient.call(spawn2);

    // Tạo publisher để điều khiển rùa
    pub1 = nh.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 10);
    pub2 = nh.advertise<geometry_msgs::Twist>("/turtle2/cmd_vel", 10);

    // Tạo subscriber để theo dõi vị trí rùa
    ros::Subscriber sub1 = nh.subscribe("/turtle1/pose", 10, poseCallback1);
    ros::Subscriber sub2 = nh.subscribe("/turtle2/pose", 10, poseCallback2);

    ros::Rate rate(10);
    geometry_msgs::Twist vel1, vel2;

    while (ros::ok()) {
        double distance = getDistance(pose1, pose2);

        if (distance < 0.3) { // Nếu có va chạm
            collision_detected = true;
        }

        if (collision_detected) {
            // Nếu có va chạm, dừng rùa lại
            vel1.linear.x = 0;
            vel1.angular.z = 1.0;
            vel2.linear.x = 0;
            vel2.angular.z = -1.0;

            // Đợi 2 giây trước khi tiếp tục
            ros::Duration(2).sleep();
            collision_detected = false;
        } else {
            // Nếu không va chạm, tiếp tục di chuyển
            vel1.linear.x = 1.0;
            vel1.angular.z = 0.5;
            vel2.linear.x = 1.0;
            vel2.angular.z = -0.5;
        }

        pub1.publish(vel1);
        pub2.publish(vel2);

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
