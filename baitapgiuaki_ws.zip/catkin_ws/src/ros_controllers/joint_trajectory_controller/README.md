## Joint Trajectory Controller ##

Controller for executing joint-space trajectories on a group of joints.

Detailed user documentation can be found in the controller's [ROS wiki page](http://wiki.ros.org/joint_trajectory_controller).


