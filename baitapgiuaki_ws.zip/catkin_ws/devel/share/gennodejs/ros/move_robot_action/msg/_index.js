
"use strict";

let MoveRobotActionResult = require('./MoveRobotActionResult.js');
let MoveRobotResult = require('./MoveRobotResult.js');
let MoveRobotActionGoal = require('./MoveRobotActionGoal.js');
let MoveRobotAction = require('./MoveRobotAction.js');
let MoveRobotActionFeedback = require('./MoveRobotActionFeedback.js');
let MoveRobotFeedback = require('./MoveRobotFeedback.js');
let MoveRobotGoal = require('./MoveRobotGoal.js');

module.exports = {
  MoveRobotActionResult: MoveRobotActionResult,
  MoveRobotResult: MoveRobotResult,
  MoveRobotActionGoal: MoveRobotActionGoal,
  MoveRobotAction: MoveRobotAction,
  MoveRobotActionFeedback: MoveRobotActionFeedback,
  MoveRobotFeedback: MoveRobotFeedback,
  MoveRobotGoal: MoveRobotGoal,
};
