
"use strict";

let TurtleGoal = require('./TurtleGoal.js')

module.exports = {
  TurtleGoal: TurtleGoal,
};
